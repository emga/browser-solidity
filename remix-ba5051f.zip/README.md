# Automatic build
Built website from `ba5051f`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-ba5051f.zip`.
